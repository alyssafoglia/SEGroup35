from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from wrapper import apiwrapper

def projAbout(request):
	return render(request, 'ScheduleDeck/projAbout.html')

def projHome(request):
	return render(request, 'ScheduleDeck/projHome.html')

def index(request):
	from django.conf import settings
	return render(request, 'ScheduleDeck/index.html')

@csrf_exempt
def simple_function(request):

	#1016~ILBiiO5jAiMdWdVaEUzw8pGHibFuvWLM0TMX2B9K8eLg62u5JR4CQkun4tMZopNw

	if request.method == "POST":
		key = request.POST.get('key')

	canvas = apiwrapper('User')
	canvas.setApiKey(key)

	my_courses = canvas.getCourses()

	for course in my_courses:
		print(my_courses[course].name)

	return HttpResponse("""<html><script>window.location.replace('/result');</script></html>""")

def result(request):
	return render(request, 'ScheduleDeck/result.html')