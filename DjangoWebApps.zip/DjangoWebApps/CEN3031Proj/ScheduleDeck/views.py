from django.shortcuts import render
from django.http import HttpResponse

def projAbout(request):
	return render(request, 'ScheduleDeck/projAbout.html')

def projHome(request):
	return render(request, 'ScheduleDeck/projHome.html')

def index(request):
	return render(request, 'ScheduleDeck/index.html')

def simple_function(request):
	print("\nThis is a simple function\n")
	return HttpResponse("""<html><script>window.location.replace('/result');</script></html>""")

def result(request):
	return render(request, 'ScheduleDeck/result.html')